window.addEventListener("load", function(){
	document.getElementById("atras").addEventListener("click", function(){
		botonatras = document.getElementById('atras');
		document.location.href = "../index.html";
	});
});